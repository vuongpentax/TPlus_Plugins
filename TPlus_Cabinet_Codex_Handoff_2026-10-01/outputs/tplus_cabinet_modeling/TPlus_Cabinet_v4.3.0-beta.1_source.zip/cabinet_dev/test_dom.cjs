const fs=require('fs');
const {JSDOM,VirtualConsole}=require('/tmp/tplus_ruby/node_modules/jsdom');
const defaults=JSON.parse(fs.readFileSync('cabinet_dev/defaults.json'));
const presets=JSON.parse(fs.readFileSync('cabinet_dev/presets.json'));
let html=fs.readFileSync('cabinet_work/TPlus_Cabinet/TPlus_Cabinet_UI.html','utf8');
for(const [key,data] of [['presets_json',presets],['default_json',defaults],['initial_json',defaults]])html=html.replace('#{'+key+'}',()=>JSON.stringify(JSON.stringify(data)).replace(/</g,'\\u003c'));
let errors=[];const vc=new VirtualConsole();vc.on('jsdomError',e=>errors.push(e.message));
const dom=new JSDOM(html,{runScripts:'dangerously',url:'https://tplus.test',virtualConsole:vc,beforeParse(w){w.calls=[];w.sketchup=new Proxy({},{get:(_,k)=>(data)=>w.calls.push({action:k,data})});}});
const w=dom.window,d=w.document;
const assert=(x,m)=>{if(!x)throw Error(m)};
setTimeout(()=>{
try{
assert(d.getElementById('btn_update').disabled,'Update enabled without selection');
w.updateCabinet(true);assert(!w.calls.some(c=>c.action==='update_cabinet'),'No-selection update');
w.placeCabinet();assert(w.calls.at(-1).action==='create_cabinet','Create route');
w.updateFormFromRuby({...defaults,__target_pid:'42'});
d.getElementById('w').value='900';w.updateCabinet(true);
let c=w.calls.at(-1);assert(c.action==='update_cabinet'&&c.data.__target_pid==='42'&&c.data.w===900,'Targeted update');
w.setSelectedCabinet(null);d.getElementById('preset_select').value='Tủ áo 3 module độc lập';w.loadPreset();
c=w.getFormData();assert(c.module_mode==='Độc lập'&&c.module_widths==='800;800;800','Module preset');
d.getElementById('drawer_count').value='1.5';d.getElementById('t').value='';c=w.getFormData();
assert(c.drawer_count===1.5&&c.t===null,'Silent numeric coercion');
const ids=[...d.querySelectorAll('[id]')].map(e=>e.id);assert(ids.length===new Set(ids).size,'Duplicate IDs');
assert(!errors.length,errors.join('\n'));
console.log('PASS DOM: startup, create, selected update, no-selection guard, presets, invalid inputs, IDs, no JS errors');
}catch(e){console.error(e);process.exitCode=1}finally{w.close();}
},650);

def assert(ok,message); raise message unless ok; end
def close(a,b); (a-b).abs < 0.0001; end
def panels(entities, offset=[0,0,0], result=[])
  entities.each do |e|
    tr=offset.zip(e.transformation.offset).map { |a,b| a+b }
    if e.is_a?(Sketchup::Group)
      faces=e.entities.grep(Sketchup::Face)
      unless faces.empty?
        pts=faces.flat_map(&:points).map { |p| p.zip(tr).map { |a,b| (a+b)*25.4 } }
        low=(0..2).map { |i| pts.map { |p| p[i] }.min }; high=(0..2).map { |i| pts.map { |p| p[i] }.max }
        result << {name:e.name, low:low, high:high, size:high.zip(low).map { |a,b| a-b }, group:e}
      end
      panels(e.entities,tr,result)
    end
  end
  result
end
def build(changes={})
  p=TPlus_Cabinet::ModelingRules.normalize(changes,TPlus_Cabinet.default_params)
  ents=Sketchup::Entities.new
  TPlus_Cabinet::Modeling.draw(ents,p)
  values=panels(ents)
  assert(values.all? { |v| v[:size].all? { |n| n.finite? && n>0 } },'Invalid panel size')
  [p,values,ents]
end
def rejected(changes)
  TPlus_Cabinet::ModelingRules.normalize(changes,TPlus_Cabinet.default_params)
  raise 'Expected validation error'
rescue TPlus_Cabinet::ModelingRules::Invalid
  true
end
p,parts=build
bottom=parts.find { |v| v[:name]=='Tấm Đáy' }
assert(close(bottom[:size][0],765),'800 with 17.5 sides must have 765 bottom')
assert(close(parts.find { |v| v[:name]=='Hồi Trái' }[:size][2],2400),'Continuous side height')
puts 'PASS: actual thickness and sandwiched bottom'
p,parts,ents=build('w'=>2400,'module_mode'=>'Độc lập','module_widths'=>'800;800;800')
assert(ents.size==3,'3 independent modules expected')
assert(parts.count { |v| ['Hồi Trái','Hồi Phải'].include?(v[:name]) }==6,'Independent modules require six sides')
assert(close(parts.map { |v| v[:high][0] }.max,2400),'Module width sum')
puts 'PASS: independent modules and overall width'
['Âm','Phủ','Không'].each do |mode|
 _,pts=build('back_mode'=>mode,'opt_door'=>'Cánh Phủ toàn bộ')
 depth=pts.map { |v| v[:high][1] }.max-pts.map { |v| v[:low][1] }.min
 assert(close(depth,600),"Overall depth failed #{mode}: #{depth}")
 assert(pts.none? { |v| v[:name].include?('Hậu') },'No-back produced a back') if mode=='Không'
 puts "PASS: back #{mode}, overall depth 600"
end
_,parts=build('h'=>2700,'is_overheight'=>true,'h_bottom'=>2100,'shelf_count_top'=>1)
sides=parts.select { |v| v[:name].start_with?('Hồi Trái','Hồi Phải') }
assert(sides.size==4 && sides.all? { |v| v[:size][2]<=2400 },'Height split invalid')
puts 'PASS: overheight splits side panels'
_,parts=build('door_stop_rail'=>true,'front_bevel'=>true,'door_top_gap'=>25)
assert(parts.any? { |v| v[:name].start_with?('Xà Chặn Cánh') },'Door rail missing')
front=parts.find { |v| v[:name]=='Cánh Trái' }
assert(close(front[:high][2],2350),'Top front gap ignored')
_,parts=build('h'=>2700,'is_overheight'=>true,'h_bottom'=>2100,'door_stop_rail'=>true)
assert(parts.any? { |v| v[:name].start_with?('Xà Chặn Cánh') },'Upper rail missing')
puts 'PASS: door top gap, bevel and stop rails'
_,parts=build('opt_drawer'=>'Âm','t'=>20,'drawer_hinge_sp'=>50,'drawer_inner_offset'=>50)
side=parts.find { |v| v[:name]=='Hông Khung Ngăn Kéo Âm Trái' }
trim=parts.find { |v| v[:name]=='Diềm Phủ Hông Ngăn Kéo Âm Trái' }
assert(close(side[:low][0]-20,30),'Concealed drawer side offset must be 30')
assert(close(trim[:size][0],50) && close(trim[:size][1],20),'Trim width and thickness mixed')
assert(parts.select { |v| v[:name].start_with?('Mặt Ngăn Kéo') }.all? { |v| v[:group].layer=='T+_CANH' },'Front tags')
puts 'PASS: concealed drawer 50 mm trim, 20 mm material, 30 mm side gap'
_,parts=build('h'=>810,'shadow_gap_h'=>0,'opt_door'=>'Không Cánh','opt_drawer'=>'Lộ','is_full_drawer'=>true,'drawer_count'=>3,'front_bevel'=>true,'drawer_gap'=>25,'drawer_backing_rail'=>true)
fronts=parts.select { |v| v[:name].start_with?('Mặt Ngăn Kéo') }
assert(fronts.size==3,'Drawer count')
assert(fronts.all? { |v| v[:group].entities.grep(Sketchup::ConstructionLine).size==1 },'Exactly one guide per front')
assert(fronts.all? { |v| v[:group].entities.grep(Sketchup::Face).first.points.size==10 },'Bevel section missing')
puts 'PASS: beveled drawer fronts, guides, backing rails'
[{ 'w'=>30 },{'t'=>0},{'module_mode'=>'Độc lập','module_widths'=>'700;700'}, {'drawer_count'=>1.5},{'opt_drawer'=>'Âm','drawer_hinge_sp'=>390},{'d'=>100,'back_recess'=>100},{'shelf_count'=>20,'h'=>200},{'front_bevel'=>true,'bevel_lip'=>30}].each { |c| rejected(c) }
puts 'PASS: eight invalid configurations rejected'

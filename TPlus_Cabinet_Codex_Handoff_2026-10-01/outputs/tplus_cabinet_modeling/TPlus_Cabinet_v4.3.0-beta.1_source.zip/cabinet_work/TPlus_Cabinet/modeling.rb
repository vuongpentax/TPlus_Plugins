# frozen_string_literal: true
module TPlus_Cabinet
  module Modeling
    module_function
    def front_solid(entities, x, dx, dy, dz, p)
      if p['front_bevel']
        cut = dy - p['bevel_lip'].to_f.mm
        raise ModelingRules::Invalid, 'Chiều cao mặt quá nhỏ để vát 45°.' unless dz > cut
        pts = [[x,0,0],[x,dy,0],[x,dy,dz-cut],[x,p['bevel_lip'].to_f.mm,dz],[x,0,dz]]
        f = entities.add_face(pts)
        raise 'Không dựng được tiết diện vát.' unless f
        f.reverse! if f.normal.x < 0
        f.pushpull(dx)
      else
        f = entities.add_face([[x,0,0],[x+dx,0,0],[x+dx,dy,0],[x,dy,0]])
        raise 'Không dựng được mặt tấm.' unless f
        f.reverse! if f.normal.z < 0
        f.pushpull(dz)
      end
    end
    def clean_tags(entities)
      model = Sketchup.active_model
      entities.each do |e|
        if e.is_a?(Sketchup::ConstructionLine)
          e.layer = model.layers['T+_KY HIEU'] || model.layers.add('T+_KY HIEU')
        elsif e.is_a?(Sketchup::Group) || e.is_a?(Sketchup::ComponentInstance)
          front = e.name.to_s.start_with?('Mặt Ngăn Kéo') || (e.respond_to?(:definition) && e.definition.name.to_s.start_with?('Cánh'))
          e.layer = front ? (model.layers['T+_CANH'] || model.layers.add('T+_CANH')) : model.layers[0]
          clean_tags(e.is_a?(Sketchup::Group) ? e.entities : e.definition.entities)
        elsif e.respond_to?(:layer=)
          e.layer = model.layers[0]
        end
      end
    end
    def draw(entities, p)
      widths = ModelingRules.widths(p)
      if p['module_mode'] == 'Độc lập'
        x = 0.0
        widths.each_with_index do |width, index|
          group = entities.add_group
          group.name = "Module #{format('%02d',index+1)} — #{width.round(1)} mm"
          child = p.merge('w'=>width, 'module_mode'=>'Chung vách')
          child['opt_left_side'] = 'Vuông' if index > 0
          child['opt_right_side'] = 'Vuông' if index < widths.size-1
          GeometryEngine.draw(group.entities, child)
          group.transform!(Geom::Transformation.translation([x.mm,0,0]))
          x += width
        end
      else
        GeometryEngine.draw(entities,p)
      end
      clean_tags(entities)
    end
  end
end

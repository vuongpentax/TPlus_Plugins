const fs=require('fs');
const {chromium}=require(process.env.CODEX_PRIMARY_RUNTIME_NODE_MODULES+'/playwright');
(async()=>{
const defaults=JSON.parse(fs.readFileSync('cabinet_dev/defaults.json'));
const presets=JSON.parse(fs.readFileSync('cabinet_dev/presets.json'));
let html=fs.readFileSync('cabinet_work/TPlus_Cabinet/TPlus_Cabinet_UI.html','utf8');
for(const [key,data] of [['presets_json',presets],['default_json',defaults],['initial_json',defaults]])html=html.replace('#{'+key+'}',()=>JSON.stringify(JSON.stringify(data)).replace(/</g,'\\u003c'));
fs.writeFileSync('cabinet_dev/preview.html',html);
const packaged=(await import('/tmp/tplus_ruby/node_modules/@sparticuz/chromium/build/index.js')).default;
const browser=await chromium.launch({headless:true,executablePath:await packaged.executablePath(),args:packaged.args});
const page=await browser.newPage({viewport:{width:560,height:640}});
let errors=[];page.on('pageerror',e=>errors.push(e.message));
await page.route('http://tplus.test/',r=>r.fulfill({body:html,contentType:'text/html'}));
await page.addInitScript(()=>{window.calls=[];window.sketchup=new Proxy({},{get:(_,k)=>(data)=>calls.push({action:k,data})});});
await page.goto('http://tplus.test/');
await page.waitForTimeout(650);
if(!await page.locator('#btn_update').isDisabled())throw Error('Update enabled without selection');
await page.evaluate(()=>updateCabinet(true));
if(await page.evaluate(()=>calls.some(c=>c.action==='update_cabinet')))throw Error('Update without selection');
await page.evaluate(()=>placeCabinet());
let call=await page.evaluate(()=>calls.at(-1));
if(call.action!=='create_cabinet'||call.data.t!==17.5)throw Error('Create payload');
await page.evaluate(p=>updateFormFromRuby({...p,__target_pid:'42'}),defaults);
await page.waitForTimeout(600);
await page.locator('#w').fill('900');
await page.locator('#btn_update').click();
call=await page.evaluate(()=>calls.at(-1));
if(call.action!=='update_cabinet'||call.data.__target_pid!=='42'||call.data.w!==900)throw Error('Update target');
await page.evaluate(()=>setSelectedCabinet(null));
await page.selectOption('#preset_select',{label:'Tủ áo 3 module độc lập'});
call=await page.evaluate(()=>getFormData());
if(call.module_mode!=='Độc lập'||call.module_widths!=='800;800;800')throw Error('Preset module fields');
await page.evaluate(()=>{document.getElementById('drawer_count').value='1.5';document.getElementById('t').value='';});
call=await page.evaluate(()=>getFormData());
if(call.drawer_count!==1.5||call.t!==null)throw Error('Input silently coerced');
await page.evaluate(p=>updateFormFromRuby(p),defaults);
for(const name of ['general','frame','compartments','doors','drawers']){
 await page.locator('[data-page="'+name+'"]').click();
 await page.waitForTimeout(180);
 await page.screenshot({path:'cabinet_dev/ui_'+name+'.png',fullPage:false});
}
await page.locator('[data-page="drawers"]').click();
await page.selectOption('#opt_drawer','Âm');
await page.screenshot({path:'cabinet_dev/ui_drawers_active.png'});
await page.locator('[data-subgroup="drawers"][data-subtab="box"]').click();
await page.screenshot({path:'cabinet_dev/ui_drawer_box.png'});
for(const viewport of [{width:560,height:640},{width:480,height:420}]){
 await page.setViewportSize(viewport);
 await page.evaluate(()=>{document.querySelectorAll('details').forEach(e=>e.open=true);document.getElementById('settings_content').scrollTop=9999;});
 const layout=await page.evaluate(()=>{const f=document.querySelector('footer').getBoundingClientRect();return {bottom:f.bottom,bodyWidth:document.body.scrollWidth,innerWidth:innerWidth,innerHeight:innerHeight,actions:[...document.querySelectorAll('.action-bar button')].every(b=>{const r=b.getBoundingClientRect();return r.top>=0&&r.bottom<=innerHeight&&r.left>=0&&r.right<=innerWidth;})}});
 if(layout.bottom>layout.innerHeight||layout.bodyWidth>layout.innerWidth||!layout.actions)throw Error('Footer clipped or horizontal overflow: '+JSON.stringify(layout));
}
await page.screenshot({path:'cabinet_dev/ui_small.png'});
if(errors.length)throw Error(errors.join('\n'));
const duplicate=await page.evaluate(()=>{let ids=[...document.querySelectorAll('[id]')].map(e=>e.id);return ids.length-new Set(ids).size;});
if(duplicate)throw Error('Duplicate IDs');
console.log('PASS UI: load, create, update target, no selection, presets, invalid numeric preservation, no JS errors, no duplicate IDs');
await browser.close();
})().catch(e=>{console.error(e);process.exitCode=1});

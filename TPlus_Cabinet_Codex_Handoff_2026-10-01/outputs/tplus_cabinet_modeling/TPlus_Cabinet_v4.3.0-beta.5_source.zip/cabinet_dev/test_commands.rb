menu = UI.menus.fetch('Extensions').items.last
toolbar = UI.toolbars.last
assert(menu.items.size == 3 && toolbar.items.size == 3, 'Expected three menu and toolbar commands')
assert(menu.items == toolbar.items, 'Menu and toolbar command mismatch')
assert(menu.items[1].name.include?('T+_EXPLODE') && menu.items[2].name.include?('T+_UNTAG'), 'Restored names missing')
assert(menu.items[1].small_icon.end_with?('combine.svg'), 'Wrong combine icon')
assert(menu.items[2].large_icon.end_with?('untag.svg'), 'Wrong untag icon')
model = Sketchup.reset
top = model.entities.add_group; dc(top); model.selection.add(top)
menu.items[1].call
assert_clean(top)
assert(model.commits == 1, 'EXPLODE menu callback not connected')
child = top.entities.add_group; child.layer = Sketchup::Layer.new('Con')
menu.items[2].call
assert(child.layer == model.layers[0] && model.commits == 2, 'UNTAG menu callback not connected')
puts 'PASS commands: three toolbar/menu buttons, correct icons, live EXPLODE/UNTAG callbacks'
